from django.apps import AppConfig


class InstapythonConfig(AppConfig):
    name = 'InstaPython'
