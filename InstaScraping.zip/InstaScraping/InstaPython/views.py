from django.shortcuts import render

import urllib.request as urllib2	
from bs4 import BeautifulSoup
from requests import get
from json import loads
import re
import json
from json import dumps
import requests
from django.http import HttpResponse

 




def internet_on():
	try:
		urllib2.urlopen('http://216.58.192.142', timeout=60)
		return True
	except urllib2.URLError as err:
		return False



def extract_hash_tags(s):
	return set([re.sub(r"#+", "#", k) for k in set([re.sub(r"(\W+)$", "", j, flags = re.UNICODE) for j in set([i for i in s.split() if i.startswith("#")])])])



def extract_mentions(s):
	return set([re.sub(r"@+", "@", k) for k in set([re.sub(r"(\W+)$", "", j, flags = re.UNICODE) for j in set([i for i in s.split() if i.startswith("@")])])])



def scrap_insta(username):

    resp=get(f"https://www.instagram.com/{username}")
    if resp.status_code == 200:
        soup=BeautifulSoup(resp.text,'html.parser')
        scripts = soup.find_all('script')

        data_script = scripts[4]

        content = data_script.contents[0]
        data_object = content[content.find('{"config"') : -1]
        data_json = loads(data_object)
        data_json = data_json['entry_data']['ProfilePage'][0]['graphql']['user']

       	followdBy=0
       	followng=0
        posts = 0
       	bioGrph=""
       	extrnalLink =""
       	userName = ""



       	followdBy=data_json['edge_followed_by']['count']
        followng=data_json['edge_follow']['count']
        posts = data_json['edge_owner_to_timeline_media']['count']
        bioGrph = data_json['biography']
        extrnalLink = data_json['external_url']
        userName = data_json['full_name']

        

        likes = []
        

        for i in range(10):
            likes.append(data_json['edge_owner_to_timeline_media']['edges'][i]['node']['edge_liked_by']['count'])
            
        


        coments = []
        for x in range(10):
        	coments.append(data_json['edge_owner_to_timeline_media']['edges'][x]['node']['edge_media_to_comment']['count'])
        

        profilePic=data_json['profile_pic_url']

        substring=""
        for i in range(10):
            substring += data_json['edge_owner_to_timeline_media']['edges'][i]['node']['edge_media_to_caption']['edges'][0]['node']['text']


        hashtage=[]
        hashtage=extract_hash_tags(substring)

        mentions=[]
        mentions=extract_mentions(substring)

        Resultz = [followdBy, followng, posts, bioGrph, extrnalLink, userName, likes, coments, profilePic, hashtage, mentions]

        return Resultz
        
    else:
    	return None





def index(request):
	return render(request, 'home.html')


def Scrap(request):
	data=[]
	name=""
	if request.method == 'POST':
		name=request.POST['User_name']

		if request.POST['submit'] == 'UserNam':
			if internet_on():
				Data = scrap_insta(name)
				if Data:
					ListLike = []
					Listcomnt = []

					Listcomnt = Data[7]
					ListLike = Data[6]


					dataJSON1 = dumps(ListLike)
					dataJSON2 = dumps(Listcomnt)

					context ={
						'followBy': Data[0],
						'followd': Data[1],
						'posts': Data[2],
						'UserBio' : Data[3],
						'UserName' : Data[5],
						'PicUrl' : Data[8],
						'ListLike': dataJSON1,
						'Listcomnt' : dataJSON2,
						'hshtgs' : Data[9],
						'mntions' : Data[10],
					}
					return render(request, 'home.html', context)
				else:
					result="User Does Not Exist"

				return render(request, 'home.html')
			else:
				result="Check Your Internet Connection..."
				return render(request, 'home.html',{'result':result})
	else:
		return render(request, 'home.html')
